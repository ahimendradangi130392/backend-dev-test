var serverlessSDK = require("./serverless_sdk/index.js");
serverlessSDK = new serverlessSDK({
  orgId: "XXXX",
  applicationName: "backend-dev-test",
  appUid: "XXXX",
  orgUid: "XXXX",
  deploymentUid: "XXXX",
  serviceName: "backend-dev-test",
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: "dev",
  serverlessPlatformStage: "prod",
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: "5.5.4",
  disableFrameworksInstrumentation: false,
});

const handlerWrapperArgs = {
  functionName: "backend-dev-test-dev-main",
  timeout: 6,
};

try {
  const userHandler = require("./_optimize/backend-dev-test-dev-main/dist/src/lambda.js");
  module.exports.handler = serverlessSDK.handler(
    userHandler.handler,
    handlerWrapperArgs
  );
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => {
    throw error;
  }, handlerWrapperArgs);
}
